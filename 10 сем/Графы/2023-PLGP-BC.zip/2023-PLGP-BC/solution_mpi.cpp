#include "defs.h"
#include "stack"
#include <algorithm> 

using namespace std;

/*Структуры для обмена данными*/
struct bfs_pkg { vertex_id_t v_glob; double sigma; };
struct bp_pkg  { vertex_id_t v_glob; double sigma; double delta; };

void brandes_distributed(graph_t* G, double* local_results) {
    /*инициализация*/
    int rank = G->rank, size = G->nproc;
    vertex_id_t N = G->n;
    vertex_id_t local_n = G->local_n;

    for (vertex_id_t i = 0; i < local_n; i++) 
        local_results[i] = 0.0;

    vector<int>    local_d(local_n);
    vector<double> local_sigma(local_n);
    vector<double> local_delta(local_n);
    vector<vector<bfs_pkg>> send_bufs(size);

    MPI_Datatype MPI_BFS_PKG, MPI_BP_PKG;
    MPI_Type_contiguous(sizeof(bfs_pkg), MPI_BYTE, &MPI_BFS_PKG);
    MPI_Type_commit(&MPI_BFS_PKG);
    MPI_Type_contiguous(sizeof(bp_pkg), MPI_BYTE, &MPI_BP_PKG);
    MPI_Type_commit(&MPI_BP_PKG);

    /*обход из каждой вершины графа*/
    for (vertex_id_t s = 0; s < N; s++) {
        fill(local_d.begin(), local_d.end(), -1);
        fill(local_sigma.begin(), local_sigma.end(), 0.0);
        fill(local_delta.begin(), local_delta.end(), 0.0);

        bool made_progress = false;
        if (VERTEX_OWNER(s, N, size) == rank) {
            vertex_id_t s_loc = VERTEX_LOCAL(s, N, size, rank);
            local_d[s_loc] = 0;
            local_sigma[s_loc] = 1.0;
            made_progress = true;
        }

        int cur_d = 0;
        bool global_active = true;
        MPI_Allreduce(&made_progress, &global_active, 1, MPI_C_BOOL, MPI_LOR, MPI_COMM_WORLD);

        /*BFS*/
        while (global_active) {
            for (int i = 0; i < size; i++) 
                send_bufs[i].clear();
            made_progress = false;

            for (vertex_id_t u_loc = 0; u_loc < local_n; u_loc++) {
                if (local_d[u_loc] == cur_d) {
                    double u_sigma = local_sigma[u_loc];
                    for (edge_id_t e = G->rowsIndices[u_loc]; e < G->rowsIndices[u_loc + 1]; e++) {
                        vertex_id_t v_glob = G->endV[e];
                        int v_owner = VERTEX_OWNER(v_glob, N, size);
                        if (v_owner == rank) {
                            vertex_id_t v_loc = VERTEX_LOCAL(v_glob, N, size, rank);
                            if (local_d[v_loc] == -1) {
                                local_d[v_loc] = cur_d + 1;
                                local_sigma[v_loc] = u_sigma;
                                made_progress = true;
                            } else if (local_d[v_loc] == cur_d + 1) local_sigma[v_loc] += u_sigma;
                        } else {
                            send_bufs[v_owner].push_back({v_glob, u_sigma});
                        }
                    }
                }
            }

            vector<int> s_counts(size), r_counts(size);
            for (int i = 0; i < size; i++) 
                s_counts[i] = send_bufs[i].size();
            
            MPI_Alltoall(s_counts.data(), 1, MPI_INT, r_counts.data(), 1, MPI_INT, MPI_COMM_WORLD);

            vector<bfs_pkg> r_data;
            int total_recv = 0;
            for (int count: r_counts) 
                total_recv += count;
            r_data.resize(total_recv);

            vector<MPI_Request> requests;
            vector<int> r_dis(size, 0);
            for (int i = 1; i < size; i++) 
                r_dis[i] = r_dis[i-1] + r_counts[i-1];

            for (int i = 0; i < size; i++) {
                if (r_counts[i] > 0) {
                    MPI_Request req;
                    MPI_Irecv(&r_data[r_dis[i]], r_counts[i], MPI_BFS_PKG, i, 0, MPI_COMM_WORLD, &req);
                    requests.push_back(req);
                }
            }

            for (int i = 0; i < size; i++) {
                if (s_counts[i] > 0) {
                    MPI_Request req;
                    MPI_Isend(send_bufs[i].data(), s_counts[i], MPI_BFS_PKG, i, 0, MPI_COMM_WORLD, &req);
                    requests.push_back(req);
                }
            }
            MPI_Waitall(requests.size(), requests.data(), MPI_STATUSES_IGNORE);

            for (const auto& pkg: r_data) {
                vertex_id_t v_loc = VERTEX_LOCAL(pkg.v_glob, N, size, rank);
                if (local_d[v_loc] == -1) {
                    local_d[v_loc] = cur_d + 1;
                    local_sigma[v_loc] = pkg.sigma;
                    made_progress = true;
                } else if (local_d[v_loc] == cur_d + 1) local_sigma[v_loc] += pkg.sigma;
            }

            MPI_Allreduce(&made_progress, &global_active, 1, MPI_C_BOOL, MPI_LOR, MPI_COMM_WORLD);
            cur_d++;
        }

        /*Обратный ход*/
        for (int lv = cur_d - 1; lv > 0; lv--) {
            vector<bp_pkg> level_data;
            for(vertex_id_t i=0; i<local_n; i++) {
                if(local_d[i] == lv) {
                    level_data.push_back({VERTEX_TO_GLOBAL(i, N, size, rank), local_sigma[i], local_delta[i]});
                    local_results[i] += local_delta[i];
                }
            }

            int local_count = level_data.size();
            vector<int> r_counts(size);
            MPI_Allgather(&local_count, 1, MPI_INT, r_counts.data(), 1, MPI_INT, MPI_COMM_WORLD);

            int total_lv = 0;
            vector<int> r_dis(size, 0);
            for (int i = 0; i < size; i++) {
                r_dis[i] = total_lv;
                total_lv += r_counts[i];
            }

            vector<bp_pkg> recv_level(total_lv);
            vector<MPI_Request> requests;

            for (int i = 0; i < size; i++) {
                if (r_counts[i] > 0) {
                    MPI_Request req;
                    MPI_Irecv(&recv_level[r_dis[i]], r_counts[i], MPI_BP_PKG, i, 1, MPI_COMM_WORLD, &req);
                    requests.push_back(req);
                }
            }
            for (int i = 0; i < size; i++) {
                if (local_count > 0) {
                    MPI_Request req;
                    MPI_Isend(level_data.data(), local_count, MPI_BP_PKG, i, 1, MPI_COMM_WORLD, &req);
                    requests.push_back(req);
                }
            }
            MPI_Waitall(requests.size(), requests.data(), MPI_STATUSES_IGNORE);

            sort(recv_level.begin(), recv_level.end(), [](const bp_pkg& a, const bp_pkg& b) {
                return a.v_glob < b.v_glob;
            });

            for (vertex_id_t u_loc = 0; u_loc < local_n; u_loc++) {
                if (local_d[u_loc] == lv - 1) {
                    double u_sigma = local_sigma[u_loc], d_sum = 0;
                    for (edge_id_t e = G->rowsIndices[u_loc]; e < G->rowsIndices[u_loc + 1]; e++) {
                        vertex_id_t v_glob = G->endV[e];
                        auto it = lower_bound(recv_level.begin(), recv_level.end(), v_glob, 
                                             [](const bp_pkg& p, vertex_id_t val){ return p.v_glob < val; });
                        if (it != recv_level.end() && it->v_glob == v_glob)
                            d_sum += (u_sigma / it->sigma) * (1.0 + it->delta);
                    }
                    local_delta[u_loc] += d_sum;
                }
            }
        }
    }

    /*Нормализация, так как граф неориентированный*/
    for (vertex_id_t i = 0; i < local_n; i++) 
        local_results[i] /= 2.0;

    MPI_Type_free(&MPI_BFS_PKG); MPI_Type_free(&MPI_BP_PKG);
}


/* algorithm */
void run(graph_t *G, double *result)
{
    brandes_distributed(G, result);
}